# Discord Server Nuker

Welcome to the Net Nuker, a powerful tool designed to efficiently nuke Discord servers. With this tool, you have a lot of options that make you able to customize exactly how you want to nuke the server.

![image](https://github.com/Berusar/discord-server-nuke-bot/assets/168286501/df50bd95-8891-493c-a7ab-56ce5e10ca1c)

## Showcases

https://www.youtube.com/watch?v=MxJCJ8QagWY
https://www.youtube.com/watch?v=joYhozSWr0U

## Features

### Option <1>
- **Preset Nuker**: With this feature you are able to set a nuking preset in the config file. Then, you can also use the config to nuke the server and you don't need to always input your message etc yourself.

### Option <2>
- **Custom Nuker**: When choosing this option, the tool will ask you all of the information it needs to do the nuke before it starts. [Message getting spammed, etc]

### Option <3>
- **Separate Menu**: This second menu is now giving you the option to use features of the tool separately. The features are listed below:
  
![image](https://github.com/Berusar/discord-server-nuke-bot/assets/168286501/ff95883c-d909-4698-94e1-93342d53f98f)

## Installation

To get started with the Discord Server Nuker, follow these steps:

0. <a href="https://www.python.org/downloads/" style="color: blue;">Install Python</a>

1. Save the repository as a zip file on your PC.

2. Extract the ZIP file.

3. Open InstallRequirements.bat to install the Python requirements. When its done:

4. Run the nuker by opening start.bat or typing `python main.py` into cmd in the correct path.

5. Enjoy!

## Note: Make sure to put a bot token into the bottoken.txt file. If you dont do so, the tool might just instantly close again!!

## Usage

Once the Discord Server Nuker is up and running, you can utilize its powerful features through simple commands. Also make sure to setup your config for easier & faster nuking ;)

## Disclaimer

I do not encourage nuking discord servers. This is just a showcase of a coding project. I take no responsibility for harm caused by this software.
